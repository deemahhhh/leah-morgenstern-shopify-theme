/* ============================================
   LEAH MORGENSTERN FINE JEWELRY
   Theme JavaScript
   ============================================ */

(function () {
  'use strict';

  /* ── Header Scroll Behavior ── */
  const header = document.querySelector('.site-header');
  const isHomepage = document.body.classList.contains('template-index');

  function updateHeader() {
    if (!header) return;
    if (isHomepage) {
      if (window.scrollY > 60) {
        header.classList.remove('is-transparent');
        header.classList.add('is-solid');
      } else {
        header.classList.remove('is-solid');
        header.classList.add('is-transparent');
      }
    } else {
      header.classList.remove('is-transparent');
      header.classList.add('is-solid');
    }
  }

  if (isHomepage && header) {
    header.classList.add('is-transparent');
  }

  window.addEventListener('scroll', updateHeader, { passive: true });
  updateHeader();

  /* ── Mobile Menu ── */
  const mobileMenu = document.getElementById('mobile-menu');
  const menuToggles = document.querySelectorAll('.menu-toggle');
  const mobileMenuClose = document.querySelector('.mobile-menu__close');
  const mobileMenuOverlay = document.querySelector('.mobile-menu__overlay');

  function openMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.add('is-open');
    mobileMenu.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileMenu() {
    if (!mobileMenu) return;
    mobileMenu.classList.remove('is-open');
    mobileMenu.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  menuToggles.forEach(btn => btn.addEventListener('click', openMobileMenu));
  if (mobileMenuClose) mobileMenuClose.addEventListener('click', closeMobileMenu);
  if (mobileMenuOverlay) mobileMenuOverlay.addEventListener('click', closeMobileMenu);

  /* ── Cart Drawer ── */
  const cartDrawer = document.getElementById('cart-drawer');
  const cartOverlay = document.querySelector('.cart-drawer__overlay');
  const cartClose = document.querySelector('.cart-drawer__close');
  const cartDrawerBody = document.getElementById('cart-drawer-body');
  const cartDrawerSubtotal = document.getElementById('cart-drawer-subtotal');
  const cartCountEls = document.querySelectorAll('.cart-count');

  function openCartDrawer() {
    if (!cartDrawer) return;
    cartDrawer.classList.add('is-open');
    cartDrawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    fetchCart();
  }

  function closeCartDrawer() {
    if (!cartDrawer) return;
    cartDrawer.classList.remove('is-open');
    cartDrawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  if (cartClose) cartClose.addEventListener('click', closeCartDrawer);
  if (cartOverlay) cartOverlay.addEventListener('click', closeCartDrawer);

  function formatMoney(cents) {
    return '$' + (cents / 100).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  function updateCartCount(count) {
    cartCountEls.forEach(el => {
      el.textContent = count;
      el.classList.toggle('is-empty', count === 0);
    });
  }

  function renderCartItems(cart) {
    if (!cartDrawerBody) return;

    if (cart.item_count === 0) {
      cartDrawerBody.innerHTML = `
        <div class="cart-drawer__empty">
          <p>Your cart is empty.</p>
          <a href="/collections/all" class="btn--ghost">Continue Shopping</a>
        </div>`;
      if (cartDrawerSubtotal) cartDrawerSubtotal.textContent = '$0.00';
      return;
    }

    const items = cart.items.map(item => `
      <div class="cart-item" data-key="${item.key}">
        <div class="cart-item__image">
          ${item.image ? `<img src="${item.image}" alt="${item.title}" loading="lazy">` : ''}
        </div>
        <div class="cart-item__info">
          <div class="cart-item__title">${item.product_title}</div>
          ${item.variant_title && item.variant_title !== 'Default Title'
            ? `<div class="cart-item__variant">${item.variant_title}</div>` : ''}
          <div class="cart-item__bottom">
            <div class="cart-item__qty">
              <button class="cart-item__qty-btn" data-action="decrease" data-key="${item.key}" data-qty="${item.quantity - 1}">−</button>
              <span class="cart-item__qty-num">${item.quantity}</span>
              <button class="cart-item__qty-btn" data-action="increase" data-key="${item.key}" data-qty="${item.quantity + 1}">+</button>
            </div>
            <div class="cart-item__price">${formatMoney(item.final_line_price)}</div>
          </div>
          <button class="cart-item__remove" data-key="${item.key}">Remove</button>
        </div>
      </div>
    `).join('');

    cartDrawerBody.innerHTML = items;
    if (cartDrawerSubtotal) cartDrawerSubtotal.textContent = formatMoney(cart.total_price);

    // Bind qty/remove events
    cartDrawerBody.querySelectorAll('.cart-item__qty-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        updateCartItem(btn.dataset.key, parseInt(btn.dataset.qty));
      });
    });

    cartDrawerBody.querySelectorAll('.cart-item__remove').forEach(btn => {
      btn.addEventListener('click', () => {
        updateCartItem(btn.dataset.key, 0);
      });
    });
  }

  function fetchCart() {
    fetch('/cart.js')
      .then(r => r.json())
      .then(cart => {
        renderCartItems(cart);
        updateCartCount(cart.item_count);
      })
      .catch(console.error);
  }

  function updateCartItem(key, qty) {
    fetch('/cart/change.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: key, quantity: qty })
    })
      .then(r => r.json())
      .then(cart => {
        renderCartItems(cart);
        updateCartCount(cart.item_count);
      })
      .catch(console.error);
  }

  // Add to Cart
  document.addEventListener('submit', function (e) {
    const form = e.target.closest('form[action="/cart/add"]');
    if (!form) return;
    e.preventDefault();

    const btn = form.querySelector('[type="submit"]');
    const originalText = btn ? btn.textContent : '';
    if (btn) {
      btn.textContent = 'Adding...';
      btn.disabled = true;
    }

    const formData = new FormData(form);

    fetch('/cart/add.js', {
      method: 'POST',
      body: formData
    })
      .then(r => r.json())
      .then(() => {
        if (btn) {
          btn.textContent = 'Added';
          setTimeout(() => {
            btn.textContent = originalText;
            btn.disabled = false;
          }, 1500);
        }
        openCartDrawer();
        fetchCart();
      })
      .catch(err => {
        console.error(err);
        if (btn) {
          btn.textContent = originalText;
          btn.disabled = false;
        }
      });
  });

  // Cart icon opens drawer
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-open-cart]')) {
      e.preventDefault();
      openCartDrawer();
    }
  });

  // Initial cart count
  fetch('/cart.js')
    .then(r => r.json())
    .then(cart => updateCartCount(cart.item_count))
    .catch(() => {});

  /* ── Product Gallery ── */
  const gallery = document.querySelector('.product-page__gallery');
  if (gallery) {
    const mainImg = gallery.querySelector('.product-gallery__main img');
    const thumbs = gallery.querySelectorAll('.product-gallery__thumb');

    thumbs.forEach((thumb, i) => {
      thumb.addEventListener('click', () => {
        const newSrc = thumb.querySelector('img')?.src;
        if (mainImg && newSrc) {
          mainImg.src = newSrc;
          mainImg.srcset = '';
        }
        thumbs.forEach(t => t.classList.remove('is-active'));
        thumb.classList.add('is-active');
      });
    });
  }

  /* ── Variant Selection ── */
  document.querySelectorAll('.variant-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const group = this.closest('.variant-options');
      group.querySelectorAll('.variant-btn').forEach(b => b.classList.remove('is-selected'));
      this.classList.add('is-selected');

      const hiddenInput = this.closest('form')?.querySelector('input[name="id"]');
      if (hiddenInput) hiddenInput.value = this.dataset.variantId;
    });
  });

  /* ── Accordion ── */
  document.querySelectorAll('.accordion-trigger').forEach(trigger => {
    trigger.addEventListener('click', function () {
      const item = this.closest('.accordion-item');
      const body = item.querySelector('.accordion-body');
      const isOpen = item.classList.contains('is-open');

      // Close all
      document.querySelectorAll('.accordion-item').forEach(i => {
        i.classList.remove('is-open');
        i.querySelector('.accordion-body')?.classList.remove('is-open');
      });

      // Open clicked if it was closed
      if (!isOpen) {
        item.classList.add('is-open');
        body?.classList.add('is-open');
      }
    });
  });

  /* ── Testimonials Slider ── */
  const testimonialSlider = document.querySelector('.testimonials__slider');
  if (testimonialSlider) {
    const slides = testimonialSlider.querySelectorAll('.testimonials__slide');
    const dots = document.querySelectorAll('.testimonials__dot');
    let current = 0;
    let autoplay;

    function goToSlide(index) {
      slides[current].style.display = 'none';
      dots[current]?.classList.remove('is-active');
      current = index;
      slides[current].style.display = 'block';
      dots[current]?.classList.add('is-active');
    }

    function startAutoplay() {
      autoplay = setInterval(() => {
        goToSlide((current + 1) % slides.length);
      }, 5000);
    }

    if (slides.length > 0) {
      slides.forEach((s, i) => s.style.display = i === 0 ? 'block' : 'none');
      dots[0]?.classList.add('is-active');
      startAutoplay();

      dots.forEach((dot, i) => {
        dot.addEventListener('click', () => {
          clearInterval(autoplay);
          goToSlide(i);
          startAutoplay();
        });
      });
    }
  }

  /* ── Smooth Reveal Animations ── */
  if ('IntersectionObserver' in window) {
    const elements = document.querySelectorAll('.section, .product-card, .editorial, .commission');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    elements.forEach(el => {
      el.classList.add('reveal');
      observer.observe(el);
    });
  }

  /* ── Reveal CSS ── */
  const style = document.createElement('style');
  style.textContent = `
    .reveal { opacity: 0; transform: translateY(24px); transition: opacity 0.7s ease, transform 0.7s ease; }
    .reveal.is-visible { opacity: 1; transform: none; }
  `;
  document.head.appendChild(style);

})();
